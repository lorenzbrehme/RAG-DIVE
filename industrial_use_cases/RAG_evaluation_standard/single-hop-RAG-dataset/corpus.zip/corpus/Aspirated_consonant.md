# Aspirated_consonant

Although most aspirated obstruents in the world's language are stops and affricates, aspirated fricatives such as [sʰ], [fʰ] or [ɕʰ] have been documented in Korean, in a few Tibeto-Burman languages, in some Oto-Manguean languages, and in the Siouan language Ofo. Some languages, such as Choni Tibetan, have up to four contrastive aspirated fricatives [sʰ] [ɕʰ], [ʂʰ] and [xʰ].

Armenian and Cantonese have aspiration that lasts about as long as English aspirated stops, in addition to unaspirated stops. Korean has lightly aspirated stops that fall between the Armenian and Cantonese unaspirated and aspirated stops as well as strongly aspirated stops whose aspiration lasts longer than that of Armenian or Cantonese. (See voice-onset time.)

Aspirated consonants are not always followed by vowels or other voiced sounds. For example, in Eastern Armenian, aspiration is contrastive even word-finally, and aspirated consonants occur in consonant clusters. In Wahgi, consonants are aspirated only in final position.

Aspiration has varying significance in different languages. It is either allophonic or phonemic, and may be analyzed as an underlying consonant cluster.

Aspiration varies with place of articulation. The Spanish voiceless stops /p t k/ have voice-onset times (VOTs) of about 5, 10, and 30 milliseconds, whereas English aspirated /p t k/ have VOTs of about 60, 70, and 80 ms. Voice-onset time in Korean has been measured at 20, 25, and 50 ms for /p t k/ and 90, 95, and 125 for /pʰ tʰ kʰ/.

Icelandic and Faroese have preaspirated [ʰp ʰt ʰk]; some scholars interpret these as consonant clusters as well. In Icelandic, preaspirated stops contrast with double stops and single stops:

In Danish and most southern varieties of German, the "lenis" consonants transcribed for historical reasons as ⟨b d ɡ⟩ are distinguished from their fortis counterparts ⟨p t k⟩, mainly in their lack of aspiration.

In many languages, such as Armenian, Korean, Thai, Indo-Aryan languages, Dravidian languages, Icelandic, Ancient Greek, and the varieties of Chinese, tenuis and aspirated consonants are phonemic. Unaspirated consonants like [p˭ s˭] and aspirated consonants like [pʰ ʰp sʰ] are separate phonemes, and words are distinguished by whether they have one or the other.

In phonetics, aspiration is the strong burst of breath that accompanies either the release or, in the case of preaspiration, the closure of some obstruents. In English, aspirated consonants are allophones in complementary distribution with their unaspirated counterparts, but in some other languages, notably most Indian and East Asian languages, the difference is contrastive.

In some languages, such as English, aspiration is allophonic. Stops are distinguished primarily by voicing, and voiceless stops are sometimes aspirated, while voiced stops are usually unaspirated.

In the International Phonetic Alphabet (IPA), aspirated consonants are written using the symbols for voiceless consonants followed by the aspiration modifier letter ⟨◌ʰ⟩, a superscript form of the symbol for the voiceless glottal fricative ⟨h⟩. For instance, ⟨p⟩ represents the voiceless bilabial stop, and ⟨pʰ⟩ represents the aspirated bilabial stop.

Later, during the Koine Greek period, the aspirated and voiceless stops /tʰ d/ of Attic Greek lenited to voiceless and voiced fricatives, yielding /θ ð/ in Medieval and Modern Greek.

Many Indo-Aryan languages have aspirated stops. Sanskrit, Hindi, Bengali, Marathi, and Gujarati have a four-way distinction in stops: voiceless, aspirated, voiced, and breathy-voiced or voiced aspirated, such as /p pʰ b bʱ/. Punjabi has lost breathy-voiced consonants, which resulted in a tone system, and therefore has a distinction between voiceless, aspirated, and voiced: /p pʰ b/.

Phonetically in some languages, such as Navajo, aspiration of stops tends to be realised as voiceless velar airflow; aspiration of affricates is realised as an extended length of the frication.

Preaspirated consonants are marked by placing the aspiration modifier letter before the consonant symbol: ⟨ʰp⟩ represents the preaspirated bilabial stop.

Preaspirated stops also occur in most Sami languages; for example, in North Sami, the unvoiced stop and affricate phonemes /p/, /t/, /ts/, /tʃ/, /k/ are pronounced preaspirated ([ʰp], [ʰt] [ʰts], [ʰtʃ], [ʰk]) when they occur in medial or final position.

So-called voiced aspirated consonants are nearly always pronounced instead with breathy voice, a type of phonation or vibration of the vocal folds. The modifier letter ⟨◌ʰ⟩ after a voiced consonant actually represents a breathy-voiced or murmured dental stop, as with the "voiced aspirated" bilabial stop ⟨bʰ⟩ in the Indo-Aryan languages. This consonant is therefore more accurately transcribed as ⟨b̤⟩, with the diacritic for breathy voice, or with the modifier letter ⟨bʱ⟩, a superscript form of the symbol for the voiced glottal fricative ⟨ɦ⟩.

Some forms of Greek before the Koine Greek period are reconstructed as having aspirated stops. The Classical Attic dialect of Ancient Greek had a three-way distinction in stops like Eastern Armenian: /t tʰ d/. These stops were called ψιλά, δασέα, μέσα "thin, thick, middle" by Koine Greek grammarians.

Some linguists restrict the double-dot subscript ⟨◌̤⟩ to murmured sonorants, such as vowels and nasals, which are murmured throughout their duration, and use the superscript hook-aitch ⟨◌ʱ⟩ for the breathy-voiced release of obstruents.

Some of the Dravidian languages, such as Telugu, Tamil, Malayalam, and Kannada, have a distinction between voiced and voiceless, aspirated and unaspirated only in loanwords from Indo-Aryan languages. In native Dravidian words, there is no distinction between these categories and stops are underspecified for voicing and aspiration.

Standard Chinese (Mandarin) has stops and affricates distinguished by aspiration: for instance, /t tʰ/, /t͡s t͡sʰ/. In pinyin, tenuis stops are written with letters that represent voiced consonants in English, and aspirated stops with letters that represent voiceless consonants. Thus d represents /t/, and t represents /tʰ/.

The other Ancient Greek dialects, Ionic, Doric, Aeolic, and Arcadocypriot, likely had the same three-way distinction at one point, but Doric seems to have had a fricative in place of /tʰ/ in the Classical period, and the Ionic and Aeolic dialects sometimes lost aspiration (psilosis).

The term aspiration sometimes refers to the sound change of debuccalization, in which a consonant is lenited (weakened) to become a glottal stop or fricative [ʔ h ɦ].

There are no dedicated IPA symbols for degrees of aspiration and typically only two degrees are marked: unaspirated ⟨k⟩ and aspirated ⟨kʰ⟩. An old symbol for light aspiration was ⟨ʻ⟩, but this is now obsolete. The aspiration modifier letter may be doubled to indicate especially strong or long aspiration. Hence, the two degrees of aspiration in Korean stops are sometimes transcribed ⟨kʰ kʰʰ⟩ or ⟨kʻ⟩ and ⟨kʰ⟩, but they are usually transcribed [k] and [kʰ], with the details of voice-onset time given numerically.

There were aspirated stops at three places of articulation: labial, coronal, and velar /pʰ tʰ kʰ/. Earlier Greek, represented by Mycenaean Greek, likely had a labialized velar aspirated stop /kʷʰ/, which later became labial, coronal, or velar depending on dialect and phonetic environment.

They are unaspirated for almost all speakers when immediately following word-initial s, as in spill, still, skill. After an s elsewhere in a word they are normally unaspirated as well, except sometimes in compound words. When the consonants in a cluster like st are analyzed as belonging to different morphemes (heteromorphemic) the stop is aspirated, but when they are analyzed as belonging to one morpheme the stop is unaspirated.[citation needed] For instance, distend has unaspirated [t] since it is not analyzed as two morphemes, but distaste has an aspirated middle [tʰ] because it is analyzed as dis- + taste and the word taste has an aspirated initial t.

To feel or see the difference between aspirated and unaspirated sounds, one can put a hand or a lit candle in front of one's mouth, and say pin [pʰɪn] and then spin [spɪn]. One should either feel a puff of air or see a flicker of the candle flame with pin that one does not get with spin. In most dialects of English, the initial consonant is aspirated in pin and unaspirated in spin.

True aspirated voiced consonants, as opposed to murmured (breathy-voice) consonants such as the [bʱ], [dʱ], [ɡʱ] that are common in the languages of India, are extremely rare. They have been documented in Kelabit Taa, and the Kx'a languages. Reported aspirated voiced stops, affricates and clicks are [b͡pʰ, d͡tʰ, d͡tsʰ, d͡tʃʰ, ɡ͡kʰ, ɢ͡qʰ, ᶢʘʰ, ᶢǀʰ, ᶢǁʰ, ᶢǃʰ, ᶢǂʰ].

Unaspirated or tenuis consonants are occasionally marked with the modifier letter for unaspiration ⟨◌˭⟩, a superscript equal sign: ⟨t˭⟩. Usually, however, unaspirated consonants are left unmarked: ⟨t⟩.

Voiced consonants are seldom actually aspirated. Symbols for voiced consonants followed by ⟨◌ʰ⟩, such as ⟨bʰ⟩, typically represent consonants with breathy voiced release (see below). In the grammatical tradition of Sanskrit, aspirated consonants are called voiceless aspirated, and breathy-voiced consonants are called voiced aspirated.

Voiceless consonants are produced with the vocal folds open (spread) and not vibrating, and voiced consonants are produced when the vocal folds are fractionally closed and vibrating (modal voice). Voiceless aspiration occurs when the vocal cords remain open after a consonant is released. An easy way to measure this is by noting the consonant's voice-onset time, as the voicing of a following vowel cannot begin until the vocal cords close.

Western Armenian has a two-way distinction between aspirated and voiced: /tʰ d/. Western Armenian aspirated /tʰ/ corresponds to Eastern Armenian aspirated /tʰ/ and voiced /d/, and Western voiced /d/ corresponds to Eastern voiceless /t/.

When aspirated consonants are doubled or geminated, the stop is held longer and then has an aspirated release. An aspirated affricate consists of a stop, fricative, and aspirated release. A doubled aspirated affricate has a longer hold in the stop portion and then has a release consisting of the fricative and aspiration.

Wu Chinese has a three-way distinction in stops and affricates: /p pʰ b/. In addition to aspirated and unaspirated consonants, there is a series of muddy consonants, like /b/. These are pronounced with slack or breathy voice: that is, they are weakly voiced. Muddy consonants as initial cause a syllable to be pronounced with low pitch or light (陽 yáng) tone.