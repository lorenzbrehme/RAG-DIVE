# Tristan_da_Cunha

During World War II, the islands were used as a top secret Royal Navy weather and radio station codenamed HMS Atlantic Isle, to monitor Nazi U-boats (which were required to maintain radio contact) and shipping movements in the South Atlantic Ocean. The first Administrator, Surgeon Lieutenant Commander E.J.S. Woolley, was appointed by the British government during this time.

In 1816, the United Kingdom annexed the islands, ruling them from the Cape Colony in South Africa. This is reported to have primarily been a measure to ensure that the French would be unable to use the islands as a base for a rescue operation to free Napoleon Bonaparte from his prison on Saint Helena. The occupation also prevented the United States from using Tristan da Cunha as a cruiser base, as it had during the War of 1812.

In 1867, Prince Alfred, Duke of Edinburgh and second son of Queen Victoria, visited the islands. The main settlement, Edinburgh of the Seven Seas, was named in honour of his visit. Lewis Carroll's youngest brother, the Reverend Edwin Heron Dodgson, served as an Anglican missionary and schoolteacher in Tristan da Cunha in the 1880s.

In 1958 as part of an experiment, Operation Argus, the United States Navy detonated an atomic bomb 160 kilometres (100 mi) high in the upper atmosphere about 175 kilometres (109 mi) southeast of the main island.

On 12 January 1938 by Letters Patent the islands were declared a dependency of Saint Helena. Prior to roughly this period, passing ships stopped irregularly at the island for a period of mere hours.

On 13 February 2008, fire destroyed the fishing factory and the four generators that supplied power to the island. On 14 March 2008, new generators were installed and uninterrupted power was restored. This fire was devastating to the island because fishing is a mainstay of the economy. While a new factory was being planned and built, M/V Kelso came to the island and acted as a factory ship, with island fishermen based on board for stints normally of one week. The new facility was ready in July 2009, for the start of the 2009–10 fishing season.

On 16 March 2011, the freighter MS Oliva ran aground on Nightingale Island, spilling tons of heavy fuel oil into the ocean, leaving an oil slick threatening the island's population of rockhopper penguins. Nightingale Island has no fresh water, so the penguins were transported to Tristan da Cunha for cleaning.

On 23 May 2001, the islands experienced an extratropical cyclone that generated winds up to 190 kilometres per hour (120 mph). A number of structures were severely damaged and a large number of cattle were killed, prompting emergency aid, provided by the British government.

On 4 December 2007 an outbreak of an acute virus-induced flu was reported. This outbreak was compounded by Tristan's lack of suitable and sufficient medical supplies.

On November 2011, the sailing boat Puma's Mar Mostro participant in Volvo Ocean Race arrived to the island after her mast broke in the first leg from Alicante and Cape Town. This event made the island, its inhabitants and lifestyle known worldwide thanks to the media reports.

The 1961 eruption of Queen Mary's Peak forced the evacuation of the entire population via Cape Town to England. The following year a Royal Society expedition went to the islands to assess the damage, and reported that the settlement of Edinburgh of the Seven Seas had been only marginally affected. Most families returned in 1963.

The first permanent settler was Jonathan Lambert, from Salem, Massachusetts, United States, who arrived at the islands in December 1810 with two other men. Lambert publicly declared the islands his property and named them the Islands of Refreshment. After being joined by an Andrew Millet, three of the four men died in 1812; however, the survivor among the original three permanent settlers, Thomas Currie (or Tommaso Corri) remained as a farmer on the island.

The islands were first sighted in 1506 by Portuguese explorer Tristão da Cunha; rough seas prevented a landing. He named the main island after himself, Ilha de Tristão da Cunha, which was anglicised from its earliest mention on British Admiralty charts to Tristan da Cunha Island. Some sources state that the Portuguese made the first landing in 1520, when the Lás Rafael captained by Ruy Vaz Pereira called at Tristan for water. The first undisputed landing was made in 1643 by the crew of the Heemstede, captained by Claes Gerritsz Bierenbroodspot.

The islands were occupied by a garrison of British Marines and a civilian population was gradually built up. Whalers also set up on the islands as a base for operations in the Southern Atlantic. However, the opening of the Suez Canal in 1869, together with the gradual move from sailing ships to coal-fired steam ships, increased the isolation of the islands, as they were no longer needed as a stopping port or for shelter for journeys from Europe to East Asia.

Tristan da Cunha /ˈtrɪstən də ˈkuːnjə/, colloquially Tristan, is both a remote group of volcanic islands in the south Atlantic Ocean and the main island of that group. It is the most remote inhabited archipelago in the world, lying 2,000 kilometres (1,200 mi) from the nearest inhabited land, Saint Helena, 2,400 kilometres (1,500 mi) from the nearest continental land, South Africa, and 3,360 kilometres (2,090 mi) from South America. The territory consists of the main island, also named Tristan da Cunha, which has a north–south length of 11.27 kilometres (7.00 mi) and has an area of 98 square kilometres (38 sq mi), along with the smaller, uninhabited Nightingale Islands and the wildlife reserves of Inaccessible and Gough Islands.

Tristan da Cunha is part of the British overseas territory of Saint Helena, Ascension and Tristan da Cunha. This includes Saint Helena and equatorial Ascension Island some 3,730 kilometres (2,318 mi) to the north of Tristan. The island has a population of 267 as of January 2016.