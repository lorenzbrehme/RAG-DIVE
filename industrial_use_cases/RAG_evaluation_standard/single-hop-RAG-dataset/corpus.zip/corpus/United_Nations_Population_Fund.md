# United_Nations_Population_Fund

According to UNFPA these elements promote the right of "reproductive health", that is physical, mental, and social health in matters related to reproduction and the reproductive system.

But Amnesty International found no evidence that UNFPA had supported the coercion. A 2001 study conducted by the pro-life Population Research Institute (PRI) falsely claimed that the UNFPA shared an office with the Chinese family planning officials who were carrying out forced abortions. "We located the family planning offices, and in that family planning office, we located the UNFPA office, and we confirmed from family planning officials there that there is no distinction between what the UNFPA does and what the Chinese Family Planning Office does," said Scott Weinberg, a spokesman for PRI. However, United Nations Members disagreed and approved UNFPA’s new country program me in January 2006. The more than 130 members of the “Group of 77” developing countries in the United Nations expressed support for the UNFPA programmes. In addition, speaking for European democracies -- Norway, Denmark, Sweden, Finland, the Netherlands, France, Belgium, Switzerland and Germany -- the United Kingdom stated, ”UNFPA’s activities in China, as in the rest of the world, are in strict conformity with the unanimously adopted Programme of Action of the ICPD, and play a key role in supporting our common endeavor, the promotion and protection of all human rights and fundamental freedoms.”

Contributions from governments and the private sector to UNFPA in 2014 exceeded $1 billion. The amount includes $477 million to the organization’s core resources and $529 million earmarked for specific programs and initiatives.

Executive Directors and Under-Secretaries General of the UN
2011–present Dr Babatunde Osotimehin (Nigeria)
2000–2010 Ms Thoraya Ahmed Obaid (Saudi Arabia)
1987–2000 Dr Nafis Sadik (Pakistan)
1969–87 Mr Rafael M. Salas (Philippines)

From 2002 through 2008, the Bush Administration denied funding to UNFPA that had already been allocated by the US Congress, partly on the refuted claims that the UNFPA supported Chinese government programs which include forced abortions and coercive sterilizations. In a letter from the Undersecretary of State for Political Affairs Nicholas Burns to Congress, the administration said it had determined that UNFPA’s support for China’s population program “facilitates (its) government’s coercive abortion program”, thus violating the Kemp-Kasten Amendment, which bans the use of United States aid to finance organizations that support or take part in managing a program of coercive abortion of sterilization.

However, according to then-Secretary of State Colin Powell, the UNFPA contributed vehicles and computers to the Chinese to carry out their population control policies. However, both the Washington Post and the Washington Times reported that Powell simply fell in line, signing a brief written by someone else.

In America, nonprofit organizations like Friends of UNFPA (formerly Americans for UNFPA) worked to compensate for the loss of United States federal funding by raising private donations.

In January 2009 President Barack Obama restored US funding to UNFPA, saying in a public statement that he would "look forward to working with Congress to restore US financial support for the UN Population Fund. By resuming funding to UNFPA, the US will be joining 180 other donor nations working collaboratively to reduce poverty, improve the health of women and children, prevent HIV/AIDS and provide family planning assistance to women in 154 countries."

In September 2015, the 193 member states of the United Nations unanimously adopted the Sustainable Development Goals, a set of 17 goals aiming to transform the world over the next 15 years. These goals are designed to eliminate poverty, discrimination, abuse and preventable deaths, address environmental destruction, and usher in an era of development for all people, everywhere.

In response, the EU decided to fill the gap left behind by the US under the Sandbaek report. According to its Annual Report for 2008, the UNFPA received its funding mainly from European Governments: Of the total income of M845.3 M, $118 was donated by the Netherlands, $67 M by Sweden, $62 M by Norway, $54 M by Denmark, $53 M by the UK, $52 M by Spain, $19 M by Luxembourg. The European Commission donated further $36 M. The most important non-European donor State was Japan ($36 M). The number of donors exceeded 180 in one year.

President Bush denied funding to the UNFPA. Over the course of the Bush Administration, a total of $244 million in Congressionally approved funding was blocked by the Executive Branch.

Rep. Christopher H. Smith (R-NJ), criticized the State Department investigation, saying the investigators were shown "Potemkin Villages" where residents had been intimidated into lying about the family-planning program. Dr. Nafis Sadik, former director of UNFPA said her agency had been pivotal in reversing China's coercive population control methods, but a 2005 report by Amnesty International and a separate report by the United States State Department found that coercive techniques were still regularly employed by the Chinese, casting doubt upon Sadik's statements.

The Fund raises awareness of and supports efforts to meet these needs in developing countries, advocates close attention to population concerns, and helps developing nations formulate policies and strategies in support of sustainable development. Dr. Osotimehin assumed leadership in January 2011. The Fund is also represented by UNFPA Goodwill Ambassadors and a Patron.

The Sustainable Development Goals are ambitious, and they will require enormous efforts across countries, continents, industries and disciplines - but they are achievable. UNFPA is working with governments, partners and other UN agencies to directly tackle many of these goals - in particular Goal 3 on health, Goal 4 on education and Goal 5 on gender equality - and contributes in a variety of ways to achieving many of the rest.

The UNFPA supports programs in more than 150 countries, territories and areas spread across four geographic regions: Arab States and Europe, Asia and the Pacific, Latin America and the Caribbean, and sub-Saharan Africa. Around three quarters of the staff work in the field. It is a member of the United Nations Development Group and part of its Executive Committee.

The United Nations Population Fund (UNFPA), formerly the United Nations Fund for Population Activities, is a UN organization. The UNFPA says it "is the lead UN agency for delivering a world where every pregnancy is wanted, every childbirth is safe and every young person's potential is fulfilled."  Their work involves the improvement of reproductive health; including creation of national strategies and protocols, and providing supplies and services. The organization has recently been known for its worldwide campaign against obstetric fistula and female genital mutilation.

UNFPA began operations in 1969 as the United Nations Fund for Population Activities (the name was changed in 1987) under the administration of the United Nations Development Fund. In 1971 it was placed under the authority of the United Nations General Assembly.

UNFPA has been falsely accused by anti-family planning groups of providing support for government programs which have promoted forced-abortions and coercive sterilizations. Controversies regarding these claims have resulted in a sometimes shaky relationship between the organization and three presidential administrations, that of Ronald Reagan, George H. W. Bush and George W. Bush, withholding funding from the UNFPA.

UNFPA is the world's largest multilateral source of funding for population and reproductive health programs. The Fund works with governments and non-governmental organizations in over 150 countries with the support of the international community, supporting programs that help women, men and young people:

UNFPA provided aid to Peru's reproductive health program in the mid-to-late '90s. When it was discovered a Peruvian program had been engaged in carrying out coercive sterilizations, UNFPA called for reforms and protocols to protect the rights of women seeking assistance. UNFPA was not involved in the scandal, but continued work with the country after the abuses had become public to help end the abuses and reform laws and practices.

UNFPA works in partnership with governments, along with other United Nations agencies, communities, NGOs, foundations and the private sector, to raise awareness and mobilize the support and resources needed to achieve its mission to promote the rights and health of women and young people.

UNFPA's connection to China's administration of forced abortions was refuted by investigations carried out by various US, UK, and UN teams sent to examine UNFPA activities in China. Specifically, a three-person U.S State Department fact-finding team was sent on a two-week tour throughout China. It wrote in a report to the State Department that it found "no evidence that UNFPA has supported or participated in the management of a program of coercive abortion or involuntary sterilization in China," as has been charged by critics.