# Human_Development_Index

A HDI below 0.5 is considered to represent "low development". All 22 countries in that category are located in Africa. The highest-scoring Sub-Saharan countries, Gabon and South Africa, are ranked 119th and 121st, respectively. Nine countries departed from this category this year and joined the "medium development" group.

A HDI of 0.8 or more is considered to represent "high development". This includes all developed countries, such as those in North America, Western Europe, Oceania, and Eastern Asia, as well as some developing countries in Eastern Europe, Central and South America, Southeast Asia, the Caribbean, and the oil-rich Arabian Peninsula. Seven countries were promoted to this category this year, leaving the "medium development" group: Albania, Belarus, Brazil, Libya, Macedonia, Russia and Saudi Arabia.

A new index was released on December 18, 2008. This so-called "statistical update" covered the period up to 2006 and was published without an accompanying Human Development Report. The update is relevant due to newly released estimates of purchasing power parities (PPP), implying substantial adjustments for many countries, resulting in changes in HDI values and, in many cases, HDI ranks.

Countries in the top quartile of HDI ("very high human development" group) with a missing IHDI include: New Zealand, Liechtenstein, Japan, Hong Kong, Singapore, Republic of China (Taiwan), Andorra, United Arab Emirates, Malta, Brunei, Qatar, Bahrain and Barbados.

Countries in the top quartile of HDI ("very high human development" group) with a missing IHDI include: New Zealand, Liechtenstein, Japan, Hong Kong, Singapore, Taiwan, United Arab Emirates, Andorra, Brunei, Malta, Qatar, Bahrain, Chile, Argentina and Barbados.

Countries in the top quartile of HDI ("very high human development" group) with a missing IHDI: New Zealand, Chile, Japan, Hong Kong, Singapore, Taiwan, Liechtenstein, Brunei, Andorra, Qatar, Barbados, United Arab Emirates, and Seychelles.

Countries in the top quartile of HDI ("very high human development" group) with a missing IHDI: New Zealand, Singapore, Hong Kong, Liechtenstein, Brunei, Qatar, Saudi Arabia, Andorra, United Arab Emirates, Bahrain, Cuba, and Kuwait.

Economists Hendrik Wolff, Howard Chong and Maximilian Auffhammer discuss the HDI from the perspective of data error in the underlying health, education and income statistics used to construct the HDI. They identified three sources of data error which are due to (i) data updating, (ii) formula revisions and (iii) thresholds to classify a country’s development status and conclude that 11%, 21% and 34% of all countries can be interpreted as currently misclassified in the development bins due to the three sources of data error, respectively. The authors suggest that the United Nations should discontinue the practice of classifying countries into development bins because - they claim - the cut-off values seem arbitrary, can provide incentives for strategic behavior in reporting official statistics, and have the potential to misguide politicians, investors, charity donors and the public who use the HDI at large.[citation needed] In 2010 the UNDP reacted to the criticism and updated the thresholds to classify nations as low, medium, and high human development countries. In a comment to The Economist in early January 2011, the Human Development Report Office responded to a January 6, 2011 article in the magazine which discusses the Wolff et al. paper. The Human Development Report Office states that they undertook a systematic revision of the methods used for the calculation of the HDI and that the new methodology directly addresses the critique by Wolff et al. in that it generates a system for continuous updating of the human development categories whenever formula or data revisions take place.

LE: Life expectancy at birth
MYS: Mean years of schooling (Years that a person 25 years-of-age or older has spent in schools)
EYS: Expected years of schooling (Years that a 5-year-old child will spend in schools throughout his life)
GNIpc: Gross national income at purchasing power parity per capita

On the following table, green arrows () represent an increase in ranking over the previous study, while red arrows () represent a decrease in ranking. They are followed by the number of spaces they moved. Blue dashes () represent a nation that did not move in the rankings since the previous study.

Some countries were not included for various reasons, mainly the unavailability of certain crucial data. The following United Nations Member States were not included in the 2010 report. Cuba lodged a formal protest at its lack of inclusion. The UNDP explained that Cuba had been excluded due to the lack of an "internationally reported figure for Cuba’s Gross National Income adjusted for Purchasing Power Parity". All other indicators for Cuba were available, and reported by the UNDP, but the lack of one indicator meant that no ranking could be attributed to the country. The situation has been addressed and, in later years, Cuba has ranked as a High Human Development country.

Some countries were not included for various reasons, mainly the unavailability of certain crucial data. The following United Nations Member States were not included in the 2011 report: North Korea, Marshall Islands, Monaco, Nauru, San Marino, South Sudan, Somalia and Tuvalu.

Some countries were not included for various reasons, primarily the lack of necessary data. The following United Nations Member States were not included in the 2014 report: North Korea, Marshall Islands, Monaco, Nauru, San Marino, Somalia, India, Pakistan, South Sudan, and Tuvalu.

Some countries were not included for various reasons, such as being a non-UN member or unable or unwilling to provide the necessary data at the time of publication. Besides the states with limited recognition, the following states were also not included.

The 2009 Human Development Report by UNDP was released on October 5, 2009, and covers the period up to 2007. It was titled "Overcoming barriers: Human mobility and development". The top countries by HDI were grouped in a new category called "very high human development". The report refers to these countries as developed countries. They are:

The 2010 Human Development Report by the United Nations Development Program was released on November 4, 2010, and calculates HDI values based on estimates for 2010. Below is the list of the "very high human development" countries:

The 2010 Human Development Report introduced an Inequality-adjusted Human Development Index (IHDI). While the simple HDI remains useful, it stated that "the IHDI is the actual level of human development (accounting for inequality)," and "the HDI can be viewed as an index of 'potential' human development (or the maximum IHDI that could be achieved if there were no inequality)."

The 2010 Human Development Report was the first to calculate an Inequality-adjusted Human Development Index (IHDI), which factors in inequalities in the three basic dimensions of human development (income, life expectancy, and education). Below is a list of countries in the top quartile by IHDI:

The 2011 Human Development Report was released on 2 November 2011, and calculated HDI values based on estimates for 2011. Below is the list of the "very high human development" countries (equal to the top quartile):

The 2013 Human Development Report by the United Nations Development Program was released on March 14, 2013, and calculates HDI values based on estimates for 2012. Below is the list of the "very high human development" countries:

The 2014 Human Development Report by the United Nations Development Program was released on July 24, 2014, and calculates HDI values based on estimates for 2013. Below is the list of the "very high human development" countries:

The 2015 Human Development Report by the United Nations Development Program was released on December 14, 2015, and calculates HDI values based on estimates for 2014. Below is the list of the "very high human development" countries:

The HDI has extended its geographical coverage: David Hastings, of the United Nations Economic and Social Commission for Asia and the Pacific, published a report geographically extending the HDI to 230+ economies, whereas the UNDP HDI for 2009 enumerates 182 economies and coverage for the 2010 HDI dropped to 169 countries.

The Human Development Index (HDI) is a composite statistic of life expectancy, education, and income per capita indicators, which are used to rank countries into four tiers of human development. A country scores higher HDI when the life expectancy at birth is longer, the education period is longer, and the income per capita is higher. The HDI was developed by the Pakistani economist Mahbub ul Haq, often framed in terms of whether people are able to "be" and "do" desirable things in their life, and was published by the United Nations Development Programme.

The Human Development Index has been criticized on a number of grounds including alleged ideological biases towards egalitarianism and so-called "Western models of development", failure to include any ecological considerations, lack of consideration of technological development or contributions to the human civilization, focusing exclusively on national performance and ranking, lack of attention to development from a global perspective, measurement error of the underlying statistics, and on the UNDP's changes in formula which can lead to severe misclassification in the categorisation of 'low', 'medium', 'high' or 'very high' human development countries.

The Human Development Report for 2007/2008 was launched in Brasília, Brazil, on November 27, 2007. Its focus was on "Fighting climate change: Human solidarity in a divided world." Most of the data used for the report are derived largely from 2005 or earlier, thus indicating an HDI for 2005. Not all UN member states choose to or are able to provide the necessary statistics.

The Inequality-adjusted Human Development Index (IHDI) is a "measure of the average level of human development of people in a society once inequality is taken into account."

The formula defining the HDI is promulgated by the United Nations Development Programme (UNDP). In general, to transform a raw variable, say , into a unit-free index between 0 and 1 (which allows different indices to be added together), the following formula is used:

The list below displays the top-ranked country from each year of the Human Development Index. Norway has been ranked the highest twelve times, Canada eight times, followed by Japan which has been ranked highest three times. Iceland has been ranked highest twice.

The origins of the HDI are found in the annual Development Reports of the United Nations Development Programme (UNDP). These were devised and launched by Pakistani economist Mahbub ul Haq in 1990 and had the explicit purpose "to shift the focus of development economics from national income accounting to people-centered policies". To produce the Human Development Reports, Mahbub ul Haq formed a group of development economists including Paul Streeten, Frances Stewart, Gustav Ranis, Keith Griffin, Sudhir Anand, and Meghnad Desai. Working alongside Nobel laureate Amartya Sen, they worked on capabilities and functions that provided the underlying conceptual framework. Haq was sure that a simple composite measure of human development was needed in order to convince the public, academics, and politicians that they can and should evaluate development not only by economic advances but also improvements in human well-being. Sen initially opposed this idea, but he soon went on to help Haq develop the Index. Sen was worried that it was going to be difficult to capture the full complexity of human capabilities in a single index, but Haq persuaded him that only a single number would shift the immediate attention of politicians from economic to human well-being.

The report showed a small increase in world HDI in comparison with last year's report. This rise was fueled by a general improvement in the developing world, especially of the least developed countries group. This marked improvement at the bottom was offset with a decrease in HDI of high income countries.